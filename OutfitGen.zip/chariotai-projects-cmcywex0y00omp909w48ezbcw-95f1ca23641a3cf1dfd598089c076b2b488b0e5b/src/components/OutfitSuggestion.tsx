import { motion } from 'framer-motion';
import { OutfitSuggestion as OutfitSuggestionType } from '../types';

interface OutfitSuggestionProps {
  outfit: OutfitSuggestionType;
  onSelect?: () => void;
  isSelected?: boolean;
}

function OutfitSuggestion({ outfit, onSelect, isSelected = false }: OutfitSuggestionProps) {
  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.8) return 'text-green-600 bg-green-100';
    if (confidence >= 0.6) return 'text-yellow-600 bg-yellow-100';
    return 'text-red-600 bg-red-100';
  };

  const getConfidenceText = (confidence: number) => {
    if (confidence >= 0.8) return 'Great Match';
    if (confidence >= 0.6) return 'Good Match';
    return 'Fair Match';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className={`bg-white rounded-2xl shadow-sm border-2 transition-all cursor-pointer overflow-hidden ${
        isSelected 
          ? 'border-rose-400 shadow-lg' 
          : 'border-gray-100 hover:border-rose-200 hover:shadow-md'
      }`}
      onClick={onSelect}
    >
      {/* Outfit Images */}
      <div className="p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mb-4">
          {outfit.items.map((item, index) => (
            <div key={item.id} className="aspect-square rounded-lg overflow-hidden bg-gray-50">
              <img
                src={item.imageUrl}
                alt={item.name}
                className="w-full h-full object-cover"
              />
            </div>
          ))}
        </div>

        {/* Outfit Details */}
        <div className="space-y-3">
          {/* Confidence and Weather */}
          <div className="flex items-center justify-between">
            <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getConfidenceColor(outfit.confidence)}`}>
              {getConfidenceText(outfit.confidence)}
            </span>
            <span className="text-sm text-gray-600">{outfit.weatherSuitability}</span>
          </div>

          {/* Items List */}
          <div>
            <h4 className="font-medium text-gray-800 mb-2">Outfit Items:</h4>
            <div className="space-y-1">
              {outfit.items.map((item) => (
                <div key={item.id} className="flex items-center gap-2 text-sm">
                  <div className="w-3 h-3 rounded-full border border-gray-200" 
                       style={{ backgroundColor: item.color === 'white' ? '#f3f4f6' : item.color }}>
                  </div>
                  <span className="text-gray-700 capitalize">{item.name}</span>
                  <span className="text-gray-500">({item.category})</span>
                </div>
              ))}
            </div>
          </div>

          {/* Occasion */}
          {outfit.occasion !== 'surprise' && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Perfect for:</span>
              <span className="inline-block px-2 py-1 bg-purple-100 text-purple-700 text-sm rounded-md capitalize">
                {outfit.occasion}
              </span>
            </div>
          )}

          {/* Color Coordination */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-600">Colors:</span>
            <div className="flex gap-1">
              {[...new Set(outfit.items.map(item => item.color))].map((color, index) => (
                <div
                  key={index}
                  className="w-4 h-4 rounded-full border border-gray-200"
                  style={{ backgroundColor: color === 'white' ? '#f3f4f6' : color }}
                  title={color}
                />
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="px-4 pb-4">
        <button
          onClick={(e) => {
            e.stopPropagation();
            if (onSelect) onSelect();
          }}
          className="w-full bg-gradient-to-r from-rose-400 to-purple-500 text-white py-2 rounded-lg font-medium hover:from-rose-500 hover:to-purple-600 transition-all"
        >
          {outfit.occasion === 'surprise' ? 'Love This Surprise!' : 'Choose This Outfit'}
        </button>
      </div>
    </motion.div>
  );
}

export default OutfitSuggestion;