import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { WeatherData } from '../types';
import { getCurrentWeather, getWeatherBasedRecommendations } from '../utils/weatherApi';

interface WeatherWidgetProps {
  onWeatherChange?: (weather: WeatherData) => void;
}

function WeatherWidget({ onWeatherChange }: WeatherWidgetProps) {
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [loading, setLoading] = useState(true);
  const [city, setCity] = useState('New York');

  useEffect(() => {
    loadWeather();
  }, [city]);

  useEffect(() => {
    if (weather && onWeatherChange) {
      onWeatherChange(weather);
    }
  }, [weather, onWeatherChange]);

  const loadWeather = async () => {
    setLoading(true);
    try {
      const weatherData = await getCurrentWeather(city);
      setWeather(weatherData);
    } catch (error) {
      console.error('Error loading weather:', error);
    } finally {
      setLoading(false);
    }
  };

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case 'sunny':
        return (
          <svg className="w-8 h-8 text-yellow-500" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2.25a.75.75 0 01.75.75v2.25a.75.75 0 01-1.5 0V3a.75.75 0 01.75-.75zM7.5 12a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM18.894 6.166a.75.75 0 00-1.06-1.06l-1.591 1.59a.75.75 0 101.06 1.061l1.591-1.59zM21.75 12a.75.75 0 01-.75.75h-2.25a.75.75 0 010-1.5H21a.75.75 0 01.75.75zM17.834 18.894a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 10-1.061 1.06l1.59 1.591zM12 18a.75.75 0 01.75.75V21a.75.75 0 01-1.5 0v-2.25A.75.75 0 0112 18zM7.758 17.303a.75.75 0 00-1.061-1.06l-1.591 1.59a.75.75 0 001.06 1.061l1.591-1.59zM6 12a.75.75 0 01-.75.75H3a.75.75 0 010-1.5h2.25A.75.75 0 016 12zM6.697 7.757a.75.75 0 001.06-1.06l-1.59-1.591a.75.75 0 00-1.061 1.06l1.59 1.591z" />
          </svg>
        );
      case 'cloudy':
        return (
          <svg className="w-8 h-8 text-gray-500" fill="currentColor" viewBox="0 0 24 24">
            <path fillRule="evenodd" d="M4.5 9.75a6 6 0 0111.573-2.226 3.75 3.75 0 014.133 4.303A4.5 4.5 0 0118 20.25H6.75a5.25 5.25 0 01-2.23-10.004 6.072 6.072 0 01-.02-.496z" clipRule="evenodd" />
          </svg>
        );
      case 'rainy':
        return (
          <svg className="w-8 h-8 text-blue-500" fill="currentColor" viewBox="0 0 24 24">
            <path fillRule="evenodd" d="M4.5 9.75a6 6 0 0111.573-2.226 3.75 3.75 0 014.133 4.303A4.5 4.5 0 0118 20.25H6.75a5.25 5.25 0 01-2.23-10.004 6.072 6.072 0 01-.02-.496z" clipRule="evenodd" />
            <path d="M10.5 21l-.75-1.5L8.25 21l1.5-3 1.5 3-.75 1.5zM13.5 21l-.75-1.5L11.25 21l1.5-3 1.5 3-.75 1.5zM16.5 21l-.75-1.5L14.25 21l1.5-3 1.5 3-.75 1.5z" />
          </svg>
        );
      default:
        return (
          <svg className="w-8 h-8 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
            <path fillRule="evenodd" d="M4.5 9.75a6 6 0 0111.573-2.226 3.75 3.75 0 014.133 4.303A4.5 4.5 0 0118 20.25H6.75a5.25 5.25 0 01-2.23-10.004 6.072 6.072 0 01-.02-.496z" clipRule="evenodd" />
          </svg>
        );
    }
  };

  if (loading) {
    return (
      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-rose-100">
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-8 bg-gray-200 rounded w-1/2 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-2/3"></div>
        </div>
      </div>
    );
  }

  if (!weather) {
    return (
      <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-rose-100">
        <p className="text-gray-500">Unable to load weather data</p>
        <button
          onClick={loadWeather}
          className="mt-2 text-rose-600 hover:text-rose-700 font-medium"
        >
          Try again
        </button>
      </div>
    );
  }

  const recommendations = getWeatherBasedRecommendations(weather);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-rose-100"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-800">Current Weather</h3>
        <button
          onClick={loadWeather}
          className="text-gray-400 hover:text-gray-600 transition-colors"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </div>

      <div className="flex items-center gap-4 mb-4">
        {getWeatherIcon(weather.condition)}
        <div>
          <div className="text-3xl font-bold text-gray-800">{weather.temperature}°F</div>
          <div className="text-gray-600 capitalize">{weather.description}</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
        <div>
          <span className="text-gray-500">Humidity:</span>
          <span className="ml-1 font-medium">{weather.humidity}%</span>
        </div>
        <div>
          <span className="text-gray-500">Wind:</span>
          <span className="ml-1 font-medium">{weather.windSpeed} mph</span>
        </div>
      </div>

      {/* Weather Recommendations */}
      <div className="border-t border-gray-200 pt-4">
        <h4 className="font-medium text-gray-800 mb-2">Outfit Recommendations</h4>
        <div className="space-y-2">
          <div>
            <span className="text-sm text-gray-600">Recommended:</span>
            <div className="flex flex-wrap gap-1 mt-1">
              {recommendations.categories.slice(0, 3).map((category, index) => (
                <span
                  key={index}
                  className="inline-block px-2 py-1 bg-green-100 text-green-700 text-xs rounded-md"
                >
                  {category}
                </span>
              ))}
            </div>
          </div>
          {recommendations.suggestions.length > 0 && (
            <div>
              <span className="text-sm text-gray-600">Tip:</span>
              <p className="text-sm text-gray-700 mt-1">{recommendations.suggestions[0]}</p>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  );
}

export default WeatherWidget;