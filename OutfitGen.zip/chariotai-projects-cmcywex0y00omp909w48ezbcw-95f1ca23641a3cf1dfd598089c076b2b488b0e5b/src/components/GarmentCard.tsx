import { motion } from 'framer-motion';
import { GarmentItem } from '../types';

interface GarmentCardProps {
  garment: GarmentItem;
  onDelete?: () => void;
  isSelected?: boolean;
  onClick?: () => void;
}

function GarmentCard({ garment, onDelete, isSelected = false, onClick }: GarmentCardProps) {
  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'tops':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        );
      case 'bottoms':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        );
      case 'outerwear':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 100 4m0-4v2m0-6V4" />
          </svg>
        );
      case 'shoes':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        );
      case 'accessories':
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
          </svg>
        );
      default:
        return (
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
          </svg>
        );
    }
  };

  const getFormalityColor = (formality: string) => {
    switch (formality) {
      case 'formal':
        return 'bg-purple-100 text-purple-700';
      case 'business':
        return 'bg-blue-100 text-blue-700';
      case 'casual':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <motion.div
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      className={`bg-white rounded-2xl shadow-sm border-2 transition-all cursor-pointer overflow-hidden ${
        isSelected 
          ? 'border-rose-400 shadow-lg' 
          : 'border-gray-100 hover:border-rose-200 hover:shadow-md'
      }`}
      onClick={onClick}
    >
      {/* Image */}
      <div className="aspect-square overflow-hidden bg-gray-50">
        <img
          src={garment.imageUrl}
          alt={garment.name}
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-semibold text-gray-800 capitalize truncate flex-1">
            {garment.name}
          </h3>
          {onDelete && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDelete();
              }}
              className="text-gray-400 hover:text-red-500 transition-colors ml-2"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          )}
        </div>

        {/* Category and Color */}
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-1 text-gray-600">
            {getCategoryIcon(garment.category)}
            <span className="text-sm capitalize">{garment.category}</span>
          </div>
          <div className="w-4 h-4 rounded-full border border-gray-200" 
               style={{ backgroundColor: garment.color === 'white' ? '#f3f4f6' : garment.color }}>
          </div>
        </div>

        {/* Formality Badge */}
        <div className="mb-3">
          <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium capitalize ${getFormalityColor(garment.formality)}`}>
            {garment.formality}
          </span>
        </div>

        {/* Tags */}
        {garment.tags.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {garment.tags.slice(0, 3).map((tag, index) => (
              <span
                key={index}
                className="inline-block px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-md"
              >
                {tag}
              </span>
            ))}
            {garment.tags.length > 3 && (
              <span className="inline-block px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-md">
                +{garment.tags.length - 3}
              </span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}

export default GarmentCard;