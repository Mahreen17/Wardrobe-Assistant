import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

function Index() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Hero Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center py-16"
      >
        <h1 className="text-5xl font-bold text-gray-800 mb-6">
          Your AI-Powered
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-rose-400 to-purple-600"> Wardrobe Assistant</span>
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Upload photos of your clothes, get intelligent outfit suggestions, and never wonder what to wear again.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link
            to="/wardrobe"
            className="bg-gradient-to-r from-rose-400 to-purple-500 text-white px-8 py-3 rounded-lg font-semibold hover:from-rose-500 hover:to-purple-600 transition-all transform hover:scale-105"
          >
            Start Building Your Wardrobe
          </Link>
          <Link
            to="/outfits"
            className="border-2 border-rose-300 text-rose-600 px-8 py-3 rounded-lg font-semibold hover:bg-rose-50 transition-colors"
          >
            Get Outfit Ideas
          </Link>
        </div>
      </motion.div>

      {/* Features Grid */}
      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="grid md:grid-cols-3 gap-8 py-16"
      >
        <div className="bg-white/60 backdrop-blur-sm p-8 rounded-2xl border border-rose-100 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-3">Smart Image Recognition</h3>
          <p className="text-gray-600">Upload photos and let AI automatically identify and categorize your clothing items.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-sm p-8 rounded-2xl border border-rose-100 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 15a4 4 0 004 4h9a5 5 0 10-.1-9.999 5.002 5.002 0 10-9.78 2.096A4.001 4.001 0 003 15z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-3">Weather-Based Suggestions</h3>
          <p className="text-gray-600">Get outfit recommendations that match the current weather and temperature.</p>
        </div>

        <div className="bg-white/60 backdrop-blur-sm p-8 rounded-2xl border border-rose-100 text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-800 mb-3">Creative Combinations</h3>
          <p className="text-gray-600">Discover new outfit combinations with our "Surprise Me" feature for fresh inspiration.</p>
        </div>
      </motion.div>

      {/* Call to Action */}
      <motion.div 
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="bg-gradient-to-r from-rose-100 to-purple-100 rounded-2xl p-12 text-center"
      >
        <h2 className="text-3xl font-bold text-gray-800 mb-4">Ready to Transform Your Wardrobe?</h2>
        <p className="text-lg text-gray-600 mb-8">Join thousands of users who've revolutionized their daily outfit decisions.</p>
        <Link
          to="/wardrobe"
          className="bg-gradient-to-r from-rose-400 to-purple-500 text-white px-10 py-4 rounded-lg font-semibold hover:from-rose-500 hover:to-purple-600 transition-all transform hover:scale-105 inline-block"
        >
          Get Started Now
        </Link>
      </motion.div>
    </div>
  );
}

export default Index;