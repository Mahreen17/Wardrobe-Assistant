import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import ImageUpload from '../components/ImageUpload';
import GarmentCard from '../components/GarmentCard';
import { GarmentItem } from '../types';
import { analyzeGarmentImage } from '../utils/imageRecognition';

function Wardrobe() {
  const [wardrobe, setWardrobe] = useState<GarmentItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [filter, setFilter] = useState<string>('all');

  // Load wardrobe from localStorage on component mount
  useEffect(() => {
    const savedWardrobe = localStorage.getItem('wardrobe');
    if (savedWardrobe) {
      setWardrobe(JSON.parse(savedWardrobe));
    }
  }, []);

  // Save wardrobe to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('wardrobe', JSON.stringify(wardrobe));
  }, [wardrobe]);

  const handleImageUpload = async (file: File) => {
    setIsProcessing(true);
    
    try {
      const analysis = await analyzeGarmentImage(file);
      
      // Create image URL for display
      const imageUrl = URL.createObjectURL(file);
      
      const newGarment: GarmentItem = {
        id: Date.now().toString(),
        name: `${analysis.color} ${analysis.category}`,
        category: analysis.category,
        color: analysis.color,
        season: 'all', // Default to all seasons
        formality: analysis.tags.includes('formal') ? 'formal' : 
                  analysis.tags.includes('business') ? 'business' : 'casual',
        imageUrl,
        tags: analysis.tags,
        createdAt: new Date()
      };
      
      setWardrobe(prev => [newGarment, ...prev]);
    } catch (error) {
      console.error('Error analyzing image:', error);
      alert('Sorry, there was an error analyzing your image. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDeleteGarment = (id: string) => {
    setWardrobe(prev => prev.filter(item => item.id !== id));
  };

  const filteredWardrobe = filter === 'all' 
    ? wardrobe 
    : wardrobe.filter(item => item.category === filter);

  const categories = ['all', 'tops', 'bottoms', 'outerwear', 'shoes', 'accessories'];

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold text-gray-800 mb-2">My Wardrobe</h1>
        <p className="text-gray-600 mb-8">Upload photos of your clothing items to build your digital wardrobe.</p>
        
        {/* Upload Section */}
        <div className="mb-12">
          <ImageUpload onImageUpload={handleImageUpload} isProcessing={isProcessing} />
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setFilter(category)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors capitalize ${
                filter === category
                  ? 'bg-rose-500 text-white'
                  : 'bg-white text-gray-600 hover:bg-rose-50 hover:text-rose-600 border border-gray-200'
              }`}
            >
              {category} {category !== 'all' && `(${wardrobe.filter(item => item.category === category).length})`}
            </button>
          ))}
        </div>

        {/* Wardrobe Grid */}
        {filteredWardrobe.length > 0 ? (
          <motion.div 
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
          >
            {filteredWardrobe.map((item, index) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
              >
                <GarmentCard 
                  garment={item} 
                  onDelete={() => handleDeleteGarment(item.id)}
                />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div 
            className="text-center py-16"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.4 }}
          >
            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-600 mb-2">
              {filter === 'all' ? 'Your wardrobe is empty' : `No ${filter} found`}
            </h3>
            <p className="text-gray-500">
              {filter === 'all' 
                ? 'Upload your first clothing item to get started!' 
                : `Upload some ${filter} to see them here.`
              }
            </p>
          </motion.div>
        )}

        {/* Stats */}
        {wardrobe.length > 0 && (
          <motion.div 
            className="mt-12 bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-rose-100"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Wardrobe Stats</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {categories.slice(1).map((category) => {
                const count = wardrobe.filter(item => item.category === category).length;
                return (
                  <div key={category} className="text-center">
                    <div className="text-2xl font-bold text-rose-600">{count}</div>
                    <div className="text-sm text-gray-600 capitalize">{category}</div>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}

export default Wardrobe;