import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import WeatherWidget from '../components/WeatherWidget';
import OutfitSuggestion from '../components/OutfitSuggestion';
import { GarmentItem, WeatherData, OutfitSuggestion as OutfitSuggestionType } from '../types';
import { generateOutfitSuggestions, generateSurpriseMeOutfit } from '../utils/outfitLogic';

function Outfits() {
  const [wardrobe, setWardrobe] = useState<GarmentItem[]>([]);
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [outfitSuggestions, setOutfitSuggestions] = useState<OutfitSuggestionType[]>([]);
  const [surpriseOutfit, setSurpriseOutfit] = useState<OutfitSuggestionType | null>(null);
  const [selectedOccasion, setSelectedOccasion] = useState<string>('casual');
  const [loading, setLoading] = useState(false);

  // Load wardrobe from localStorage
  useEffect(() => {
    const savedWardrobe = localStorage.getItem('wardrobe');
    if (savedWardrobe) {
      setWardrobe(JSON.parse(savedWardrobe));
    }
  }, []);

  // Generate outfit suggestions when wardrobe, weather, or occasion changes
  useEffect(() => {
    if (wardrobe.length > 0 && weather) {
      generateSuggestions();
    }
  }, [wardrobe, weather, selectedOccasion]);

  const generateSuggestions = async () => {
    if (!weather) return;
    
    setLoading(true);
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const suggestions = generateOutfitSuggestions(wardrobe, weather, selectedOccasion);
    setOutfitSuggestions(suggestions);
    setLoading(false);
  };

  const handleSurpriseMe = async () => {
    if (!weather || wardrobe.length < 2) return;
    
    setLoading(true);
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const surprise = generateSurpriseMeOutfit(wardrobe, weather);
    setSurpriseOutfit(surprise);
    setLoading(false);
  };

  const occasions = [
    { value: 'casual', label: 'Casual', icon: '👕' },
    { value: 'business', label: 'Business', icon: '👔' },
    { value: 'formal', label: 'Formal', icon: '🤵' }
  ];

  if (wardrobe.length === 0) {
    return (
      <div className="max-w-4xl mx-auto text-center py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Build Your Wardrobe First</h2>
          <p className="text-gray-600 mb-8 max-w-md mx-auto">
            You need to add some clothing items to your wardrobe before we can suggest outfits for you.
          </p>
          <Link
            to="/wardrobe"
            className="bg-gradient-to-r from-rose-400 to-purple-500 text-white px-8 py-3 rounded-lg font-semibold hover:from-rose-500 hover:to-purple-600 transition-all transform hover:scale-105 inline-block"
          >
            Add Clothing Items
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold text-gray-800 mb-2">Outfit Ideas</h1>
        <p className="text-gray-600 mb-8">Get personalized outfit suggestions based on weather and occasion.</p>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Column - Weather and Controls */}
          <div className="lg:col-span-1 space-y-6">
            <WeatherWidget onWeatherChange={setWeather} />
            
            {/* Occasion Selector */}
            <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 border border-rose-100">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Occasion</h3>
              <div className="space-y-2">
                {occasions.map((occasion) => (
                  <button
                    key={occasion.value}
                    onClick={() => setSelectedOccasion(occasion.value)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                      selectedOccasion === occasion.value
                        ? 'bg-rose-100 text-rose-700 border border-rose-200'
                        : 'bg-white hover:bg-rose-50 border border-gray-200'
                    }`}
                  >
                    <span className="text-xl">{occasion.icon}</span>
                    <span className="font-medium">{occasion.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Surprise Me Button */}
            <button
              onClick={handleSurpriseMe}
              disabled={loading || !weather}
              className="w-full bg-gradient-to-r from-purple-400 to-pink-500 text-white py-4 rounded-2xl font-semibold hover:from-purple-500 hover:to-pink-600 transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
            >
              {loading ? (
                <div className="flex items-center justify-center gap-2">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Creating Surprise...</span>
                </div>
              ) : (
                <>
                  <span className="text-xl mr-2">✨</span>
                  Surprise Me!
                </>
              )}
            </button>
          </div>

          {/* Right Column - Outfit Suggestions */}
          <div className="lg:col-span-2">
            {/* Surprise Outfit */}
            {surpriseOutfit && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.4 }}
                className="mb-8"
              >
                <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center gap-2">
                  <span className="text-2xl">✨</span>
                  Your Surprise Outfit
                </h2>
                <OutfitSuggestion
                  outfit={surpriseOutfit}
                  onSelect={() => setSurpriseOutfit(null)}
                />
              </motion.div>
            )}

            {/* Regular Suggestions */}
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-6">
                Suggested Outfits for {selectedOccasion} occasions
              </h2>
              
              {loading ? (
                <div className="grid md:grid-cols-2 gap-6">
                  {[1, 2, 3, 4].map((i) => (
                    <div key={i} className="bg-white rounded-2xl p-6 animate-pulse">
                      <div className="grid grid-cols-2 gap-2 mb-4">
                        {[1, 2, 3, 4].map((j) => (
                          <div key={j} className="aspect-square bg-gray-200 rounded-lg"></div>
                        ))}
                      </div>
                      <div className="space-y-2">
                        <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                        <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : outfitSuggestions.length > 0 ? (
                <motion.div 
                  className="grid md:grid-cols-2 gap-6"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.4 }}
                >
                  {outfitSuggestions.map((outfit, index) => (
                    <motion.div
                      key={outfit.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                    >
                      <OutfitSuggestion outfit={outfit} />
                    </motion.div>
                  ))}
                </motion.div>
              ) : (
                <motion.div 
                  className="text-center py-12"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.4 }}
                >
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-semibold text-gray-600 mb-2">No outfit suggestions available</h3>
                  <p className="text-gray-500 mb-4">
                    Add more clothing items to get better outfit suggestions.
                  </p>
                  <Link
                    to="/wardrobe"
                    className="text-rose-600 hover:text-rose-700 font-medium"
                  >
                    Add more items to your wardrobe →
                  </Link>
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

export default Outfits;