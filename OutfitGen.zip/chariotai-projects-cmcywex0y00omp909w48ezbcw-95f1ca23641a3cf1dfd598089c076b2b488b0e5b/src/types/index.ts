export interface GarmentItem {
  id: string;
  name: string;
  category: 'tops' | 'bottoms' | 'outerwear' | 'shoes' | 'accessories';
  color: string;
  season: 'spring' | 'summer' | 'fall' | 'winter' | 'all';
  formality: 'casual' | 'business' | 'formal';
  imageUrl: string;
  tags: string[];
  createdAt: Date;
}

export interface WeatherData {
  temperature: number;
  condition: string;
  humidity: number;
  windSpeed: number;
  description: string;
}

export interface OutfitSuggestion {
  id: string;
  items: GarmentItem[];
  occasion: string;
  weatherSuitability: string;
  confidence: number;
}

export interface ImageRecognitionResult {
  category: GarmentItem['category'];
  color: string;
  tags: string[];
  confidence: number;
}