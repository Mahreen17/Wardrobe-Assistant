import { ImageRecognitionResult, GarmentItem } from '../types';

// Mock image recognition service - in a real app, this would integrate with Google Cloud Vision API or similar
export async function analyzeGarmentImage(file: File): Promise<ImageRecognitionResult> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Mock analysis based on filename or random selection for demo purposes
  const fileName = file.name.toLowerCase();
  
  // Simple keyword-based detection for demo
  let category: GarmentItem['category'] = 'tops';
  let color = 'blue';
  let tags: string[] = [];

  if (fileName.includes('shirt') || fileName.includes('top') || fileName.includes('blouse')) {
    category = 'tops';
    tags = ['casual', 'cotton', 'button-down'];
  } else if (fileName.includes('pants') || fileName.includes('jeans') || fileName.includes('trouser')) {
    category = 'bottoms';
    tags = ['denim', 'casual', 'straight-fit'];
  } else if (fileName.includes('jacket') || fileName.includes('coat') || fileName.includes('blazer')) {
    category = 'outerwear';
    tags = ['formal', 'wool', 'structured'];
  } else if (fileName.includes('shoe') || fileName.includes('boot') || fileName.includes('sneaker')) {
    category = 'shoes';
    tags = ['leather', 'comfortable', 'versatile'];
  } else if (fileName.includes('bag') || fileName.includes('belt') || fileName.includes('hat')) {
    category = 'accessories';
    tags = ['leather', 'statement', 'versatile'];
  }

  // Mock color detection
  const colors = ['black', 'white', 'blue', 'red', 'green', 'brown', 'gray', 'navy', 'beige', 'pink'];
  color = colors[Math.floor(Math.random() * colors.length)];

  // Add color-based tags
  if (color === 'black' || color === 'navy' || color === 'gray') {
    tags.push('neutral', 'versatile');
  }
  if (color === 'white' || color === 'beige') {
    tags.push('light', 'summer');
  }

  return {
    category,
    color,
    tags,
    confidence: 0.85 + Math.random() * 0.1 // Mock confidence between 85-95%
  };
}

// Enhanced analysis with more sophisticated mock logic
export async function enhancedGarmentAnalysis(file: File): Promise<ImageRecognitionResult> {
  const result = await analyzeGarmentImage(file);
  
  // Add seasonal and formality tags based on category and color
  const additionalTags: string[] = [];
  
  if (result.category === 'tops') {
    if (result.color === 'white' || result.color === 'light') {
      additionalTags.push('summer', 'breathable');
    }
    if (result.tags.includes('button-down')) {
      additionalTags.push('business-casual', 'professional');
    }
  }
  
  if (result.category === 'outerwear') {
    additionalTags.push('layering', 'weather-protection');
    if (result.color === 'black' || result.color === 'navy') {
      additionalTags.push('formal', 'evening');
    }
  }

  return {
    ...result,
    tags: [...result.tags, ...additionalTags]
  };
}