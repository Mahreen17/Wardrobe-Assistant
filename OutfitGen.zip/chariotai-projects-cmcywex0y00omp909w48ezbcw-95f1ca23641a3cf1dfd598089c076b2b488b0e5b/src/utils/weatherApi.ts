import { WeatherData } from '../types';

// Mock weather service - in a real app, this would integrate with OpenWeatherMap API
export async function getCurrentWeather(city: string = 'New York'): Promise<WeatherData> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Mock weather data - in production, you'd make an actual API call
  const mockWeatherConditions = [
    { condition: 'sunny', temperature: 75, description: 'Clear skies' },
    { condition: 'cloudy', temperature: 65, description: 'Partly cloudy' },
    { condition: 'rainy', temperature: 55, description: 'Light rain' },
    { condition: 'cold', temperature: 35, description: 'Cold and crisp' },
    { condition: 'hot', temperature: 85, description: 'Hot and sunny' }
  ];

  const randomWeather = mockWeatherConditions[Math.floor(Math.random() * mockWeatherConditions.length)];

  return {
    temperature: randomWeather.temperature,
    condition: randomWeather.condition,
    humidity: 45 + Math.floor(Math.random() * 30), // 45-75%
    windSpeed: 5 + Math.floor(Math.random() * 15), // 5-20 mph
    description: randomWeather.description
  };
}

export function getWeatherBasedRecommendations(weather: WeatherData): {
  categories: string[];
  avoid: string[];
  suggestions: string[];
} {
  const { temperature, condition } = weather;

  if (temperature >= 80) {
    return {
      categories: ['light tops', 'shorts', 'sandals', 'sun hat'],
      avoid: ['heavy outerwear', 'boots', 'dark colors'],
      suggestions: ['Choose breathable fabrics', 'Light colors reflect heat', 'Don\'t forget sunscreen!']
    };
  } else if (temperature >= 65) {
    return {
      categories: ['t-shirts', 'light pants', 'sneakers', 'light jacket'],
      avoid: ['heavy coats', 'winter boots'],
      suggestions: ['Perfect weather for layering', 'Light jacket for evening', 'Comfortable walking shoes']
    };
  } else if (temperature >= 45) {
    return {
      categories: ['sweaters', 'jeans', 'boots', 'jacket'],
      avoid: ['shorts', 'sandals', 'tank tops'],
      suggestions: ['Layer for warmth', 'Closed-toe shoes recommended', 'Light scarf adds style']
    };
  } else {
    return {
      categories: ['heavy coat', 'warm pants', 'boots', 'gloves'],
      avoid: ['light fabrics', 'open shoes', 'shorts'],
      suggestions: ['Bundle up!', 'Thermal layers help', 'Don\'t forget a warm hat']
    };
  }
}

export function isWeatherAppropriate(garmentTags: string[], weather: WeatherData): boolean {
  const { temperature, condition } = weather;
  
  // Check temperature appropriateness
  if (temperature >= 80 && garmentTags.includes('heavy')) return false;
  if (temperature <= 40 && garmentTags.includes('light')) return false;
  
  // Check condition appropriateness
  if (condition === 'rainy' && garmentTags.includes('suede')) return false;
  if (condition === 'sunny' && garmentTags.includes('dark') && temperature >= 75) return false;
  
  return true;
}