import { GarmentItem, OutfitSuggestion, WeatherData } from '../types';
import { isWeatherAppropriate } from './weatherApi';

export function generateOutfitSuggestions(
  wardrobe: GarmentItem[],
  weather: WeatherData,
  occasion: string = 'casual'
): OutfitSuggestion[] {
  const suggestions: OutfitSuggestion[] = [];
  
  // Filter items appropriate for weather
  const weatherAppropriateItems = wardrobe.filter(item => 
    isWeatherAppropriate(item.tags, weather)
  );

  // Group items by category
  const itemsByCategory = weatherAppropriateItems.reduce((acc, item) => {
    if (!acc[item.category]) acc[item.category] = [];
    acc[item.category].push(item);
    return acc;
  }, {} as Record<string, GarmentItem[]>);

  const tops = itemsByCategory.tops || [];
  const bottoms = itemsByCategory.bottoms || [];
  const shoes = itemsByCategory.shoes || [];
  const outerwear = itemsByCategory.outerwear || [];
  const accessories = itemsByCategory.accessories || [];

  // Generate outfit combinations
  for (let i = 0; i < Math.min(5, tops.length); i++) {
    for (let j = 0; j < Math.min(3, bottoms.length); j++) {
      const outfit: GarmentItem[] = [tops[i], bottoms[j]];
      
      // Add shoes if available
      if (shoes.length > 0) {
        const shoeIndex = Math.floor(Math.random() * shoes.length);
        outfit.push(shoes[shoeIndex]);
      }
      
      // Add outerwear based on temperature
      if (weather.temperature < 65 && outerwear.length > 0) {
        const outerwearIndex = Math.floor(Math.random() * outerwear.length);
        outfit.push(outerwear[outerwearIndex]);
      }
      
      // Occasionally add accessories
      if (accessories.length > 0 && Math.random() > 0.5) {
        const accessoryIndex = Math.floor(Math.random() * accessories.length);
        outfit.push(accessories[accessoryIndex]);
      }

      const confidence = calculateOutfitConfidence(outfit, weather, occasion);
      
      suggestions.push({
        id: `outfit-${i}-${j}`,
        items: outfit,
        occasion,
        weatherSuitability: getWeatherSuitabilityText(weather),
        confidence
      });
    }
  }

  // Sort by confidence and return top suggestions
  return suggestions
    .sort((a, b) => b.confidence - a.confidence)
    .slice(0, 6);
}

function calculateOutfitConfidence(
  outfit: GarmentItem[],
  weather: WeatherData,
  occasion: string
): number {
  let confidence = 0.5; // Base confidence

  // Color coordination bonus
  const colors = outfit.map(item => item.color);
  if (hasGoodColorCoordination(colors)) {
    confidence += 0.2;
  }

  // Weather appropriateness bonus
  const weatherAppropriate = outfit.every(item => 
    isWeatherAppropriate(item.tags, weather)
  );
  if (weatherAppropriate) {
    confidence += 0.2;
  }

  // Occasion appropriateness
  const formalityLevels = outfit.map(item => item.formality);
  if (isOccasionAppropriate(formalityLevels, occasion)) {
    confidence += 0.1;
  }

  return Math.min(confidence, 1.0);
}

function hasGoodColorCoordination(colors: string[]): boolean {
  // Simple color coordination rules
  const neutrals = ['black', 'white', 'gray', 'beige', 'navy', 'brown'];
  const neutralCount = colors.filter(color => neutrals.includes(color)).length;
  
  // If mostly neutrals, good coordination
  if (neutralCount >= colors.length - 1) return true;
  
  // If all same color family, good coordination
  const uniqueColors = [...new Set(colors)];
  if (uniqueColors.length <= 2) return true;
  
  return false;
}

function isOccasionAppropriate(formalityLevels: string[], occasion: string): boolean {
  const avgFormality = formalityLevels.reduce((acc, level) => {
    const score = level === 'formal' ? 3 : level === 'business' ? 2 : 1;
    return acc + score;
  }, 0) / formalityLevels.length;

  switch (occasion) {
    case 'formal':
      return avgFormality >= 2.5;
    case 'business':
      return avgFormality >= 1.5 && avgFormality <= 3;
    case 'casual':
      return avgFormality <= 2;
    default:
      return true;
  }
}

function getWeatherSuitabilityText(weather: WeatherData): string {
  const { temperature, condition } = weather;
  
  if (temperature >= 80) {
    return 'Perfect for hot weather';
  } else if (temperature >= 65) {
    return 'Great for mild weather';
  } else if (temperature >= 45) {
    return 'Good for cool weather';
  } else {
    return 'Suitable for cold weather';
  }
}

export function generateSurpriseMeOutfit(
  wardrobe: GarmentItem[],
  weather: WeatherData
): OutfitSuggestion | null {
  if (wardrobe.length < 2) return null;

  // Randomly select items from different categories
  const categories = ['tops', 'bottoms', 'shoes', 'outerwear', 'accessories'];
  const outfit: GarmentItem[] = [];

  for (const category of categories) {
    const categoryItems = wardrobe.filter(item => item.category === category);
    if (categoryItems.length > 0) {
      const randomItem = categoryItems[Math.floor(Math.random() * categoryItems.length)];
      outfit.push(randomItem);
    }
  }

  // Ensure we have at least a top and bottom
  if (!outfit.some(item => item.category === 'tops') || 
      !outfit.some(item => item.category === 'bottoms')) {
    return null;
  }

  return {
    id: 'surprise-outfit',
    items: outfit,
    occasion: 'surprise',
    weatherSuitability: getWeatherSuitabilityText(weather),
    confidence: 0.7 + Math.random() * 0.2 // Random confidence for surprise
  };
}